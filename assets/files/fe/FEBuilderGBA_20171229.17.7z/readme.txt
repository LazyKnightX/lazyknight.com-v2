FE_Builder_GBA
===

FE GBA 3部作のROMエディターです。
FE8J FE7J FE6 FE8U FE7U に対応しています。

Project_FE_GBA の画面を参考に、
新規に判明した部分を追加しました。
画像表示やインポートエクスポート、マップ改造まで幅広い機能をサポートします。

怪盗パッチを作っているときに思った、こんな機能が欲しい!!という機能をすべて入れ込みました。

名前の由来は、 某LANDのアレからです。
ただし、開発言語はC# です。 (中の人達は一緒だしね・・・)
C#でありますが、特にパフォーマンスに注意しているので、サクサク動くかと思います。

当然、オープンソース。ソースコードのライセンスは GPL3 です。
ご自由にご利用ください。

これを作るのに、いろいろいなデータ、コミニティを参考にしました。
解析したデータを公開してくれた先人にお礼を申し上げます。


詳細 (ページ下部に解説集があるよ)
http://ngmansion.xyz/wiki/hackfe/index.php?%E8%A7%A3%E8%AA%AC/FEBuilderGBA



FE_Builder_GBA
===

This is a ROM editor of FE GBA trilogy.

Support to FE8J FE7J FE6 FE8U FE7U.

With reference to the screen of Project_FE_GBA,
We support a wide range of functions from image display, import export, map remodeling.

I wanted this kind of function I thought when making a Kaitou patch!

The origin of the name is from 某LAND.
However, the development language is C#. (People inside are together ...)

Naturally, open source.
The license of the source code is GPL3.
Please use it freely.

To make this, I referred to various data and Communities.
We would like to thank our predecessors who released the analyzed data.


Details (There is a commentary at the bottom of the page)
http://ngmansion.xyz/wiki/hackfe/index.php?%E8%A7%A3%E8%AA%AC/FEBuilderGBA




FE_Builder_GBA
===
它是FE GBA三部曲的ROM编辑器。
它对应于FE 8 J FE 7 J FE 6 FE 8 U FE 7 U.

参考Project_FE_GBA的屏幕，
我添加了一个新发现的部分。
我们支持图像显示，导入导出，地图重构等功能。

当我制作一个kaito补丁时，我想要这样的功能

这个名字的起源是来自 某LAND。
但是，开发语言是C＃。 （里面的人在一起...）
它是C＃，但我担心性能，所以我认为它会工作很好。

当然，开源。源代码的许可证是GPL3。
请自由使用。

我参考了各种数据和社区来做到这一点。
我要感谢发布分析数据的前辈。


详细信息（页面底部有评论）
http://ngmansion.xyz/wiki/hackfe/index.php?%E8%A7%A3%E8%AA%AC/FEBuilderGBA


